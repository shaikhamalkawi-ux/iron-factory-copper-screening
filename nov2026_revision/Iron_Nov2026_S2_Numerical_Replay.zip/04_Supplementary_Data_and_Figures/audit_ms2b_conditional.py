#!/usr/bin/env python3
"""Independent, non-calibrating reviewer-response arithmetic audit for the 32-row archived source.

Conditional engineering identity only: IF the historical instrument used an MS2B 10 cm^3
sample with LF numbers read in 10^-5 SI volume-susceptibility units, the value in
10^-8 m^3/kg units is 10*LF/mass_g. This does not certify historical instrument identity.
Does not write back any workbook value. All numerical evidence is derived from
Iron_Factory_public_sanitized.xlsx via its saved XML values.
"""
import csv,hashlib,json,math,sys
from pathlib import Path
import numpy as np
from scipy import stats
from verify_mass_arithmetic import read_values,report

HERE=Path(__file__).resolve().parent
SRC=HERE/'Iron_Factory_public_sanitized.xlsx'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()=='1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b'
rows=read_values(SRC)
assert len(rows)==32
r=[]
for rid in range(1,33):
 x=rows[rid+3]; LF=x[56]; m=x[58]; XLF=x[59]; dist=x[53]
 r.append(dict(record_id=rid,LF_numeric_1e_minus5_SI_if_verified=LF,mass_g=m,XLF_archived_numeric=XLF,
      LF_over_mass_numeric=LF/m,conditional_MS2B_chi_numeric_1e_minus8_m3kg=10*LF/m,
      ten_times_archived_XLF_numeric=10*XLF,difference_XLF_minus_LF_over_mass=XLF-LF/m,
      recorded_distance_m=dist))
path=HERE/'MS2B_Conditional_Conversion_Audit.csv'
with path.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
first=set(x['recorded_distance_m'] for x in r[:16]);second=set(x['recorded_distance_m'] for x in r[16:])
assert first == {0,200,400,600,700,800,1200}
assert {150,250,260,310,360,480,770,930,1150}<=second
rank=lambda k: [x['record_id'] for x in sorted(r,key=lambda row:(-row[k],row['record_id']))]
assert rank('XLF_archived_numeric') == rank('ten_times_archived_XLF_numeric')
assert set(rank('XLF_archived_numeric')[:8])==set(rank('LF_over_mass_numeric')[:8])
assert rank('XLF_archived_numeric') != rank('LF_over_mass_numeric')
# Recompute OLS from stored source values independently of published Cu_OLS_coefficients.csv.
ys={
 'four-fraction sum': [rows[i+3][45] for i in range(1,33)],
 'F1':[rows[i+3][5] for i in range(1,33)],
 'non-residual':[sum(rows[i+3][j] for j in (5,15,25)) for i in range(1,33)]
}
X_d=np.column_stack([np.ones(32),np.log1p([x['recorded_distance_m'] for x in r])]);
X_dx=np.column_stack([X_d,np.log([x['XLF_archived_numeric'] for x in r])]);
def ols(y,X):
 a=np.log(np.array(y)); b=np.linalg.lstsq(X,a,rcond=None)[0]; resid=a-X@b;n,p=X.shape
 mse=(resid@resid)/(n-p); cov=mse*np.linalg.inv(X.T@X); se=np.sqrt(np.diag(cov));t=b/se
 pvals=2*stats.t.sf(np.abs(t),df=n-p)
 return dict(coefs=b.tolist(),se=se.tolist(),p_values=pvals.tolist(),R2=1-float(resid@resid)/float(((a-a.mean())**2).sum()))
fits={t:{'distance-only':ols(y,X_d),'distance-plus-XLF':ols(y,X_dx)} for t,y in ys.items()}
non=fits['non-residual']
assert abs(non['distance-only']['R2']-0.3715)<0.0002
assert abs(non['distance-plus-XLF']['coefs'][1]+0.117)<0.001
assert abs(non['distance-plus-XLF']['se'][1]-0.031)<0.001
assert abs(non['distance-plus-XLF']['p_values'][1]-0.0008)<0.0001
assert abs(non['distance-plus-XLF']['p_values'][2]-0.704)<0.001
assert abs(fits['four-fraction sum']['distance-only']['R2']-0.0166)<0.0001
assert abs(fits['four-fraction sum']['distance-plus-XLF']['R2']-0.4313)<0.0001
assert abs(10*r[0]['LF_over_mass_numeric']-95.0920245398773)<1e-10
print('OLS non-residual',non)
qa={
 'source_SHA256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
 'source_rows':32,
 'first_half_distance_distinct_m':sorted(first),
 'second_half_distance_distinct_m':sorted(second),
 'mass_arithmetic':report(SRC),
 'MS2B_10cm3_10e_minus5_input_conditional_only':True,
 'never_physically_certified':True,
 'conditional_formula':'chi numeric in 10^-8 m3 kg^-1 = 10 * LF numerical in 10^-5 SI / mass_g, ONLY IF MS2B volume and reported units were authentic and applicable',
 'record_1_conditional_chi_1e_minus8_m3_kg':r[0]['conditional_MS2B_chi_numeric_1e_minus8_m3kg'],
 'rank_order_identical_for_exact_10x_XLF':True,
 'top8_IDs_XLF':rank('XLF_archived_numeric')[:8],
 'top8_IDs_LF_per_mass':rank('LF_over_mass_numeric')[:8],
 'OLS_independent_refits':fits,
 'no_input_modified':True
}
(HERE/'MS2B_Conditional_Conversion_QA.json').write_text(json.dumps(qa,indent=2))
print('PASS MS2B conditional arithmetic and reviewer3 OLS source verification')
