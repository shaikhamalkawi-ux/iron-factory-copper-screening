# Supplementary Data S2 — numerical reproduction and conditional instrument audit

This archive accompanies the revised manuscript for MDPI *Environments*, environments-4640261. It contains a metadata-sanitized derivative of the declared historical scientific workbook and portable software that reproduces the frozen analytical results without altering source measurements.

Extract `Supplementary_Data_S2.zip`. Open `04_Supplementary_Data_and_Figures/`. Commands are executed from that directory:

```bash
python Baseline_Reproduction_V39/run_reproduction.py --output reproduced_results
python verify_mass_arithmetic.py Iron_Factory_public_sanitized.xlsx
python audit_ms2b_conditional.py
python verify_v43_delivery.py
python Figure_Reproduction/render_figures.py --output Figure_Reproduction/rendered
```

Dependencies: Python 3.13, NumPy 2.3.5 and SciPy 1.17.0; figure regeneration additionally needs Matplotlib and PyMuPDF. The original code's historical directory/version identifiers are retained only for command compatibility and numerical lineage; they are not new manuscript versions.

The added `MS2B_Conditional_Conversion_Audit.csv` and `MS2B_Conditional_Conversion_QA.json` are **conditional dimensional checks**, not a claim that a specific sensor head, container geometry, display unit or calibration was historically verified. The manufacturer conversion in units 10^-8 m^3/kg would be `10*LF/mass_g` **if** the archived numeric LF readings are 10^-5 SI volume susceptibility from a properly used 10 cm^3 MS2B container. The archived XLF, ranking and all 32 historical data rows were not modified.

The separate historical thesis, private original workbook, reviewer reports, unpublished magnetic worksheet and passwords are not in this public archive. Historical QA summary tables remain source transcriptions, not independently verified laboratory certificates.

---
## Baseline diagnostic inventory

# Iron V43 Supplementary Data

This complete data folder accompanies BOTH the journal-review and complete packages. Scientific input values and frozen output tables are inherited unchanged from V42. Root-level CSV/JSON aliases exactly match Baseline_Reproduction_V39/results/ and are provided to resolve filenames cited in reviewer replies.

## Commands (from this directory)

```sh
python Baseline_Reproduction_V39/run_reproduction.py --output reproduced_results
python verify_mass_arithmetic.py Iron_Factory_public_sanitized.xlsx
python Figure_Reproduction/render_figures.py --output Figure_Reproduction/rendered
python verify_v43_delivery.py
```

The baseline verifier checks 837 primary cases, 81 displayed k=8 retention values, 60 subset comparisons and the supplied correlation/regression/chance/coordinate tables. It reads the sanitized workbook without saving or recalibrating it. No new field or laboratory measurements are present. `V43_Reverification.json` records the fresh rerun; `V39_Numerical_QA.json` is the preserved earlier record.

The original private analysis workbook is not redistributed. Its sanitized scientific-value-preserving derivative is `Iron_Factory_public_sanitized.xlsx`; SHA-256: 1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b.

Source QA CSVs transcribe the historical thesis; found/reference ratios are not certified BCR recoveries, and solution mg/L detection limits are not row-level censoring flags. The thesis itself and the separate historical magnetic worksheet are not added to this package.

## Dependencies
Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 were used for the verified numeric rerun. Figure generation also uses Matplotlib and PyMuPDF; the exact local versions are recorded in `Environment_V43.json`. Figures 2 and 3 use k-axis ticks [1, 8, 15, 23, 31]. Figure 2 is the unchanged archived bitmap; the renderer regenerates the coordinate map and Cu-retention panels from frozen inputs.
