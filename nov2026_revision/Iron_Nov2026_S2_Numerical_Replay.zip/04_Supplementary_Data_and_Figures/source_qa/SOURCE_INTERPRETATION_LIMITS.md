# V41 recovered-thesis evidence boundary

- Source: original 2015 Yarmouk University MSc thesis by Emad Khaled Al-Sharadqah, internal author-provided copy.
- Table 2.3 transcription is a record of what the thesis *printed*, not independent NIST certificate verification.
- The first reference identifier is internally inconsistent: narrative SRM 1646a vs Table 2.3 SRM-1664a. No silent correction.
- Found/reference percentages are descriptive ratios from central printed values only, not BCR fraction-specific extraction recoveries.
- SRMs were described as microwave digested (printed p.33); no BCR fraction-specific CRM is reported.
- Fe row numerical units are questionable relative to table heading; no unit correction made.
- 2702 Cu certified value is missing in the printed table.
- Detection limits are reported in mg/L in analytical solutions; they cannot be imputed to any original Excel record without exact fractions/dilutions and lab logs.
- Original workbook not modified; SRM transcriptions are separate metadata.
