"""Independent, standard-library-only inspection of the *saved* Iron Factory XLSX numerical cells.

Not a physical calibration or laboratory measurement. Usage:
    python verify_mass_arithmetic.py path/to/Iron_Factory_public_sanitized.xlsx
"""
import csv
import json
import math
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


def col_index(s):
    n = 0
    for c in s:
        n = 26*n + ord(c)-ord('A')+1
    return n


def read_values(filename):
    ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    with zipfile.ZipFile(filename) as z:
        root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    rows = {}
    for row in root.findall('.//' + ns + 'sheetData/' + ns + 'row'):
        r = int(row.attrib['r'])
        if r < 4 or r > 35:
            continue
        rows[r] = {}
        for cell in row.findall(ns + 'c'):
            raw = cell.attrib['r']
            col=''.join(c for c in raw if c.isalpha())
            v = cell.find(ns + 'v')
            if v is not None and v.text is not None:
                try: rows[r][col_index(col)] = float(v.text)
                except ValueError: pass
    return rows


def report(file):
    rows=read_values(file)
    assert len(rows)==32 and all(j in rows for j in range(4,36))
    frac_cols=[list(range(c,c+9)) for c in (2,12,22,32)]
    sum_cols=list(range(42,51))
    audited=[];errors=[]
    for r in range(4,36):
        x=rows[r]; ID=int(x[1]); assert ID==r-3
        assert all(all(c in x and x[c]>0 and math.isfinite(x[c]) for c in cols) for cols in frac_cols)
        errors += [abs(x[sum_cols[j]]-sum(x[cols[j]] for cols in frac_cols)) for j in range(9)]
        L,H,m,XL,XH=(x[j] for j in (56,57,58,59,60))
        audited.append(dict(id=ID, LF=L,HF=H,mass_g=m,XLF=XL,XHF=XH,LF_over_mass=L/m,HF_over_mass=H/m,lf_difference=XL-L/m,hf_difference=XH-H/m))
    key=lambda c: [r['id'] for r in sorted(audited,key=lambda r:(-r[c],r['id']))]
    out={
        'row_count':len(audited),
        'source_fraction_values':sum(map(len,frac_cols))*len(audited),
        'source_four_fraction_sums':len(errors),
        'max_abs_sum_diff_ug_per_g':max(errors),
        'mass_g_range':[min(x['mass_g'] for x in audited),max(x['mass_g'] for x in audited)],
        'max_abs_LF_mass_minus_XLF':max(abs(x['lf_difference']) for x in audited),
        'max_abs_HF_mass_minus_XHF':max(abs(x['hf_difference']) for x in audited),
        'anomalous_HF_ID':max(audited,key=lambda x:abs(x['hf_difference']))['id'],
        'max_abs_HF_diff_excluding_8':max(abs(x['hf_difference']) for x in audited if x['id']!=8),
        'same_LF_top8_set':set(key('XLF')[:8])==set(key('LF_over_mass')[:8]),
        'full_LF_rank_order_same':key('XLF')==key('LF_over_mass'),
        'same_HF_top8_set':set(key('XHF')[:8])==set(key('HF_over_mass')[:8])
    }
    assert out['source_fraction_values']==1152 and out['source_four_fraction_sums']==288
    assert out['max_abs_sum_diff_ug_per_g']<4e-12
    assert out['max_abs_LF_mass_minus_XLF']<0.05
    assert out['max_abs_HF_mass_minus_XHF']>5
    assert out['anomalous_HF_ID']==8 and out['max_abs_HF_diff_excluding_8']<0.05
    assert out['same_LF_top8_set'] and not out['full_LF_rank_order_same']
    return out

if __name__ == '__main__':
    if len(sys.argv)!=2:raise SystemExit('Supply sanitized XLSX path')
    print(json.dumps(report(Path(sys.argv[1])),indent=2))
