# Reproduce the map and Cu-retention figure

From this folder, run:

```sh
python render_figures.py --output rendered
```

Inputs are bundled; no network or API token is used. `coordinates_reconstructed.csv` preserves the 32 archived records, including all five zero-distance codes. The Jordan outline and source provenance are supplied. The star is an approximate thesis reference location, not a surveyed factory center.

`all_837_primary_cases.csv` supplies frozen XLF/proximity cutoff envelopes; `Cu_Uniform_Expectation_By_Budget.csv` supplies the already calculated random-subset expectation. Neither is changed by rendering. The V43 change to the Cu figure is exclusively the k tick list [1, 8, 15, 23, 31], to match the unchanged all-element figure. Figure output PDFs embed fonts; the rendering script also writes PNG previews.

Install packages listed in requirements.txt. Exact successful-run versions are listed in ../Environment_V43.json. No new geospatial observation or physical calibration is inferred.
