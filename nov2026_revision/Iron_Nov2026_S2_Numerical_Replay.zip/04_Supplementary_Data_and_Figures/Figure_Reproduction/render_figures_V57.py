"""Render figures from archived geometry and frozen analytical CSVs, without network access.
Usage: python render_figures.py --output /path/to/assets
Each panel is a distinct matplotlib figure. PyMuPDF assembles the vector panels.
"""
from pathlib import Path
import argparse,csv,json,math,tempfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import fitz
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.titlesize':19,'axes.labelsize':18,'xtick.labelsize':16,'ytick.labelsize':16,'pdf.fonttype':42,'ps.fonttype':42})
def combine(paths,out):
 docs=[fitz.open(p) for p in paths]; w=sum(d[0].rect.width for d in docs);h=max(d[0].rect.height for d in docs)
 doc=fitz.open();p=doc.new_page(width=w,height=h);x=0
 for d in docs:
  r=d[0].rect;p.show_pdf_page(fitz.Rect(x,0,x+r.width,h),d,0);x+=r.width
 doc.save(out);p.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(out.with_suffix('.png'))
 for d in docs:d.close()
 doc.close()
def main(out):
 out.mkdir(parents=True,exist_ok=True)
 rows=list(csv.DictReader((ROOT/'coordinates_reconstructed.csv').open()))
 assert len(rows)==32
 lat=np.array([float(r['latitude_decimal_degrees']) for r in rows]);lon=np.array([float(r['longitude_decimal_degrees']) for r in rows]);dist=np.array([float(r['recorded_distance_m']) for r in rows]);ids=np.array([int(r['record']) for r in rows]);zero=dist==0
 la=32+23/60+14.68/3600;lo=36+16/60+9.17/3600
 geo=json.loads((ROOT/'Jordan_NaturalEarth_LowResolution.geojson').read_text())['features'][0]['geometry']; assert geo['type']=='Polygon'
 with tempfile.TemporaryDirectory() as td:
  td=Path(td)
  f,ax=plt.subplots(figsize=(4.1,5.6))
  for ring in geo['coordinates']:
   q=np.asarray(ring);ax.plot(q[:,0],q[:,1],linewidth=1.5)
  ax.scatter([lo],[la],marker='*',s=200,zorder=5)
  ax.annotate('Study area\n(Mafraq)',xy=(lo,la),xytext=(36.8,32.65),fontsize=16,arrowprops={'arrowstyle':'-'})
  ax.text(36.8,30.7,'JORDAN',ha='center',fontsize=18)
  ax.annotate('N',xy=(34.85,33.0),xytext=(34.85,32.3),ha='center',arrowprops={'arrowstyle':'-|>'},fontsize=17)
  ax.set(xlim=(34.6,39.5),ylim=(29,33.6),xlabel='Longitude (°E)',ylabel='Latitude (°N)');ax.set_aspect(1/math.cos(math.radians(31)))
  ax.set_xticks([35,37,39]);ax.set_yticks([29,31,33]);ax.set_title('(a) Study-area locator',pad=15)
  f.subplots_adjust(left=.20,right=.96,bottom=.17,top=.88);f.savefig(td/'a.pdf');plt.close(f)
  f,ax=plt.subplots(figsize=(7.7,5.6))
  ax.scatter(lon[~zero],lat[~zero],s=58,label='Positive recorded distance',zorder=3)
  ax.scatter(lon[zero],lat[zero],s=80,marker='s',label='Zero recorded distance',zorder=4)
  ax.scatter([lo],[la],s=160,marker='*',label='Thesis reference location',zorder=5)
  # Ring is a marker annotation, not a second observation.
  ax.plot(lon[ids==17],lat[ids==17],linestyle='none',marker='o',fillstyle='none',markersize=15,markeredgewidth=1.7,zorder=6)
  # Annotate only the source-audit exception; central zero-distance labels overlap.
  for i,x,y in zip(ids,lon,lat):
   if int(i)==17:
    ax.annotate('17',(x,y),xytext=(10,-2),textcoords='offset points',fontsize=15,zorder=7)
  ax.set(xlim=(36.2558,36.2845),ylim=(32.3816,32.3982),xlabel='Longitude (°E)',ylabel='Latitude (°N)')
  ax.set_aspect(1/math.cos(math.radians(la)));ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'));ax.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
  ax.set_xticks([36.26,36.27,36.28]);ax.set_yticks([32.382,32.386,32.390,32.394,32.398]);ax.grid(alpha=.15)
  ax.legend(loc='upper right',fontsize=13,framealpha=.9,handletextpad=.4)
  ax.set_title('(b) The 32 historical records',pad=15)
  f.subplots_adjust(left=.17,right=.98,bottom=.17,top=.88);f.savefig(td/'b.pdf');plt.close(f)
  combine([td/'a.pdf',td/'b.pdf'],out/'Figure1_Study_Area_and_Records.pdf')
  # Frozen envelopes: no fitting or arbitrary tie resolution.
  allrows=list(csv.DictReader((ROOT/'all_837_primary_cases.csv').open()))
  # E[R(k)] = (k/32)*sum(y)/sum(top-k y). Derive from archived values only.
  # We archive the expectation series separately, read below.
  expectations=list(csv.DictReader((ROOT/'Cu_Uniform_Expectation_By_Budget.csv').open()))
  parts=[]
  for j,targ in enumerate(['four-fraction sum','F1','non-residual']):
   z=sorted([r for r in allrows if r['element']=='Cu' and r['target']==targ],key=lambda r:int(r['k']))
   k=np.array([int(r['k']) for r in z]); a,b,c,d=[np.array([float(r[v]) for r in z]) for v in ['XLF_min','XLF_max','distance_min','distance_max']]
   chance=[float(r['uniform_expectation_percent']) for r in expectations if r['target']==targ]
   f,ax=plt.subplots(figsize=(4.4,4.6))
   ax.fill_between(k,c,d,alpha=.18)
   ax.plot(k,c,'--',linewidth=1.2,label='Proximity envelope');ax.set_prop_cycle(None);ax.plot(k,d,'--',linewidth=1.2)
   # Reset each panel's automatic cycle before drawing both bound lines as one call above is not needed for science.
   ax.errorbar(k,a,yerr=np.stack([np.zeros(len(k)),b-a]),fmt='-',linewidth=1.8,capsize=3,elinewidth=1.5,label='XLF lower + tie range')
   ax.plot(k,chance,'-.',linewidth=1.5,label='Uniform-subset mean')
   ax.axvline(8,linestyle=':',linewidth=1.1)
   ax.set(xlim=(0.45,31.65),ylim=(0,103),xlabel='Selection budget k',ylabel='Retention (%)')
   ax.set_xticks([1,8,15,23,31]);ax.tick_params(axis='x',labelsize=15)
   ax.set_title(f'({chr(97+j)}) '+['Four-fraction Cu sum','Acid-soluble F1 Cu','Non-residual Cu'][j],fontsize=18,pad=12)
   ax.grid(alpha=.15);ax.legend(loc='lower right',fontsize=12,framealpha=.92)
   f.subplots_adjust(left=.18,right=.94,bottom=.18,top=.85);p=td/f'cu{j}.pdf';f.savefig(p);plt.close(f);parts.append(p)
  combine(parts,out/'Figure3_Cu_Retention_Envelopes.pdf')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'rendered');main(p.parse_args().output)
