#!/usr/bin/env python3
"""Verify V43 delivery identities without modifying frozen source data."""
from pathlib import Path
import csv, hashlib, json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'Iron_Factory_public_sanitized.xlsx')=='1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b'
checks={}
for p in (P/'Baseline_Reproduction_V39/results').glob('*'):
 if p.suffix in ('.csv','.json') and (P/p.name).exists():
  assert sha(p)==sha(P/p.name),p.name
  checks[p.name]='BYTE_IDENTICAL'
for name,n in [('Mass_Normalization_Arithmetic_Audit.csv',32),('Thesis_SRM_Table2p3_Transcribed.csv',18),('Thesis_Solution_Detection_Limits.csv',9),('Cu_OLS_coefficients.csv',15),('chance_k8_exact.csv',27),('row_order_half_comparisons.csv',60),('all_837_primary_cases.csv',837),('frequency_dependence_diagnostics.csv',32),('coordinates_reconstructed.csv',32)]:
 with (P/name).open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 assert len(rows)==n,(name,len(rows),n)
 checks[name+'_rows']=n
assert 'ax.set_xticks([1,8,15,23,31])' in (P/'Figure_Reproduction/render_figures.py').read_text()
for name in ['all_837_primary_cases.csv','chance_k8_exact.csv','coordinates_reconstructed.csv']:
 assert sha(P/'Figure_Reproduction'/name)==sha(P/name),name
print(json.dumps({'status':'PASS','source_unchanged':True,'checks':checks},indent=2))
