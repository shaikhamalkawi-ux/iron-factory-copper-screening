#!/usr/bin/env python3
"""Read only a metadata-sanitized copy of the frozen analytical workbook. No input mutations."""
import csv, itertools, json, statistics, math, hashlib
from pathlib import Path
from collections import Counter
root=Path(__file__).resolve().parent
original=root/'Iron_Factory_public_sanitized.xlsx'
(root/'output').mkdir(exist_ok=True)
rows=json.loads((root/'public_0.json').read_text())[3:35]
assert len(rows)==32 and len(rows[0])==60
els=['Cd','Co','Cr','Cu','Fe','Mn','Ni','Pb','Zn']
rec=[]
for rr in rows:
 rec.append({'id':int(rr[0]),'distance':float(rr[52]),'XLF':float(rr[58]),'fract':{e:tuple(float(rr[x+i]) for x in (1,11,21,31)) for i,e in enumerate(els)}})
assert [x['id'] for x in rec]==list(range(1,33))
def targets(i,e):
 f=rec[i]['fract'][e]
 return (sum(f),f[0],sum(f[:3]))
def envelope(ids,k,field,reverse,e,t):
 sc={i:rec[i][field] for i in ids}
 vals=sorted(ids,key=lambda i:sc[i],reverse=reverse); cutoff=sc[vals[k-1]]
 core=[i for i in vals if sc[i]>cutoff] if reverse else [i for i in vals if sc[i]<cutoff]
 boundary=[i for i in vals if sc[i]==cutoff]
 left=k-len(core)
 assert 0<left<=len(boundary)
 denom=sum(sorted((targets(i,e)[t] for i in ids),reverse=True)[:k]);assert denom>0
 common=sum(targets(i,e)[t] for i in core)
 fractions=sorted((targets(i,e)[t] for i in boundary))
 low=100*(common+sum(fractions[:left]))/denom
 hi=100*(common+sum(fractions[-left:]))/denom
 return low,hi,math.comb(len(boundary),left)
def calc(ids,k,e,t):
 a,b,nm=envelope(ids,k,'XLF',True,e,t)
 c,d,np=envelope(ids,k,'distance',False,e,t)
 win='M' if a>d+1e-10 else ('P' if c>b+1e-10 else 'O')
 return {'M_min':a,'M_max':b,'P_min':c,'P_max':d,'n_M_sets':nm,'n_P_sets':np,'winner':win}
arr=[]
for group,ids,k in [('ALL32',range(32),8),('IDs_1-16',range(16),4),('IDs_1-16',range(16),8),('IDs_17-32',range(16,32),4),('IDs_17-32',range(16,32),8)]:
 for e in ('Co','Fe','Pb','Cu'):
  for tid,tname in enumerate(['Sum_4_fractions','F1','Non_residual']):
   arr.append({'Group':group,'n':len(ids),'k':k,'Element':e,'Target':tname,**calc(list(ids),k,e,tid)})
with (root/'output/Iron_V38_HalfSplit_60_Comparisons.csv').open('w',newline='') as fh:
 d=csv.DictWriter(fh,fieldnames=arr[0].keys());d.writeheader();d.writerows(arr)
expected={'Cd':[(21,2,8),(25,0,6),(19,4,8)],'Co':[(13,13,5),(10,17,4),(11,15,5)],'Cr':[(13,9,9),(21,5,5),(12,8,11)],'Cu':[(24,3,4),(14,12,5),(2,24,5)],'Fe':[(13,12,6),(17,9,5),(13,9,9)],'Mn':[(28,0,3),(25,3,3),(28,0,3)],'Ni':[(20,6,5),(17,7,7),(14,9,8)],'Pb':[(16,13,2),(16,12,3),(16,13,2)],'Zn':[(15,11,5),(10,11,10),(14,10,7)]}
issues=[]
for e in els:
 for t in range(3):
  ct=Counter(calc(list(range(32)),k,e,t)['winner'] for k in range(1,32))
  observed=tuple(ct.get(z,0) for z in ('M','P','O'))
  if observed!=expected[e][t]:issues.append((e,t,observed,expected[e][t]))
assert not issues,issues
# Independently verify all 81 k=8 printed retention/classification numbers to two decimals.
expected_main={
 'Cd':[(35.14,31.32,50.03,'O'),(35.18,29.69,50.97,'O'),(36.21,32.91,53.05,'O')],
 'Co':[(66.83,82.24,86.13,'P'),(51.25,74.83,80.93,'P'),(60.26,81.57,87.16,'P')],
 'Cr':[(49.71,54.27,59.13,'P'),(7.31,5.41,36.34,'O'),(27.46,30.99,43.49,'P')],
 'Cu':[(91.68,84.66,87.60,'M'),(84.32,74.14,77.30,'M'),(60.35,80.75,86.65,'P')],
 'Fe':[(66.46,86.16,90.46,'P'),(57.29,64.14,73.34,'P'),(27.59,45.57,65.71,'P')],
 'Mn':[(76.53,56.99,62.74,'M'),(72.03,50.55,54.53,'M'),(73.08,52.82,59.10,'M')],
 'Ni':[(71.22,76.96,79.86,'P'),(63.40,63.13,72.54,'O'),(63.06,73.44,79.63,'P')],
 'Pb':[(14.42,25.73,27.33,'P'),(29.21,46.91,52.36,'P'),(12.30,21.62,23.03,'P')],
 'Zn':[(60.39,64.34,94.72,'P'),(77.56,76.12,86.53,'O'),(69.00,72.84,95.62,'P')]}
maxerr=0
for e in els:
 for t in range(3):
  c=calc(list(range(32)),8,e,t)
  ex=expected_main[e][t]
  for key, v in zip(('M_min','P_min','P_max'),ex[:3]):
   maxerr=max(maxerr,abs(c[key]-v));assert abs(c[key]-v)<0.00501,(e,t,key,c[key],v)
  assert c['winner']==ex[3]
med=[]
for e in els:
 f=[statistics.median(rec[i]['fract'][e][z] for i in range(32)) for z in range(4)]
 med.append({'Element':e,**{f'F{z+1}_median_ug_g':f[z] for z in range(4)}})
with (root/'output/Iron_V38_Fraction_Medians_32Rows.csv').open('w',newline='') as fh:
 d=csv.DictWriter(fh,fieldnames=med[0].keys());d.writeheader();d.writerows(med)
with (root/'output/Iron_V38_Independent_Numerical_QA.json').open('w') as fh:
 json.dump({'n':32,'elements':9,'ordinary_cases_checked':837,'original_budget_winner_count_mismatches':len(issues),'k8_retention_values_checked':81,'max_absolute_error_to_printed_k8_percent':maxerr,'new_row_subset_comparisons':60,'source_sanitized_xlsx_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'numerical_source_mutated':False},fh,indent=2)
print('PASS 837/837 budget classifications, 81/81 k8 printed values; 60/60 half comparisons prepared; max rounding err',maxerr)
for g in ('ALL32','IDs_1-16','IDs_17-32'):
 print('\n',g)
 for e in ('Co','Fe','Pb','Cu'):
  sub=[x for x in arr if x['Group']==g and x['Element']==e and x['k']==8]
  print(e, '/'.join(x['winner'] for x in sub))
