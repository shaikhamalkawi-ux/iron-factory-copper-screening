"""Source-locked V37 new analyses. Input: author-protected verified extraction of original Iron Factory.xlsx via artifact_tool."""
import json,csv,math,itertools,re,collections
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr,mannwhitneyu,t as student_t
from scipy.spatial.distance import pdist
ROOT=Path(__file__).resolve().parent
raw=json.loads((ROOT/'public_0.json').read_text())
rows=raw[3:35]; assert len(rows)==32
names=['Cd','Co','Cr','Cu','Fe','Mn','Ni','Pb','Zn'];n=32
ids=np.array([int(r[0]) for r in rows]);assert np.array_equal(ids,np.arange(1,33))
frac=np.array([[[float(r[1+10*f+e]) for e in range(9)] for f in range(4)] for r in rows]); assert frac.shape==(32,4,9)
Y=np.stack((frac.sum(axis=1),frac[:,0,:],frac[:,:3,:].sum(axis=1)),axis=1)
d=np.array([float(r[52]) for r in rows]);direction=[str(r[51]).strip() for r in rows]
lf=np.array([float(r[55]) for r in rows]);hf=np.array([float(r[56]) for r in rows]);mass=np.array([float(r[57]) for r in rows]);xlf=np.array([float(r[58]) for r in rows]);xhf=np.array([float(r[59]) for r in rows]);
assert np.all(Y>0) and np.all(xlf>0)
mag=list(np.argsort(-xlf,kind='stable')[:8]);assert [int(ids[i]) for i in mag]==[12,8,31,19,24,26,29,16] or set(ids[mag])=={8,12,16,19,24,26,29,31}

def cutoff_sets(indices, variable, k, descending=False):
    v=np.asarray(variable)[indices]; order=np.argsort(-v if descending else v,kind='stable'); thresh=v[order[k-1]]
    before=[int(indices[j]) for j in range(len(v)) if ((v[j]>thresh) if descending else (v[j]<thresh))]; boundary=[int(indices[j]) for j in range(len(v)) if v[j]==thresh]
    choose=k-len(before)
    return [tuple(sorted(before+list(part))) for part in itertools.combinations(boundary,choose)]

def retention(selected, target, population=np.arange(n)):
    return 100*sum(target[list(selected)])/sum(sorted(target[list(population)],reverse=True)[:len(selected)])

M=cutoff_sets(np.arange(n),xlf,8,True);P=cutoff_sets(np.arange(n),d,8,False)
assert len(M)==1 and len(P)==6,(M,P)

_subset_sum_cache={}

def exact_random_p(target, k, observed):
    """Exact uniform-without-replacement one-sided tail using 16+16 meet-in-middle."""
    key=tuple(float(v) for v in target)
    if key not in _subset_sum_cache:
        _subset_sum_cache[key]=_make_exact_halves(target)
    halves=_subset_sum_cache[key]
    cnt=0
    for a in range(k+1):
        b=k-a;left,right=halves[0][a],halves[1][b]
        cnt += int(np.sum(len(right)-np.searchsorted(right,observed-left-1e-10,side="left")))
    return cnt/math.comb(n,k)

def _make_exact_halves(target):
    halves=[]
    for yy in (target[:16],target[16:]):
        sums=np.empty(65536,dtype=float); sums[0]=0
        pcs=np.empty(65536,dtype=np.uint8);pcs[0]=0
        for mask in range(1,65536):
            low=mask&(-mask);j=low.bit_length()-1;rest=mask^low
            sums[mask]=sums[rest]+yy[j];pcs[mask]=pcs[rest]+1
        halves.append([np.sort(sums[pcs==z]) for z in range(9)])
    return halves

arr=[];chance=[];cor=[]
for ei,name in enumerate(names):
    for ti,targetname in enumerate(['four-fraction sum','F1','non-residual']):
        y=Y[:,ti,ei]
        ore=sum(sorted(y,reverse=True)[:8]);retm=retention(M[0],y)
        retps=sorted(retention(s,y) for s in P)
        expected=100*(8/32)*sum(y)/ore
        p_mag=exact_random_p(y,8,sum(y[list(M[0])]))
        p_prox_low=min(exact_random_p(y,8,sum(y[list(s)])) for s in P)
        p_prox_high=max(exact_random_p(y,8,sum(y[list(s)])) for s in P)
        v=dict(element=name,target=targetname,magnetic=retm,proximity_min=retps[0],proximity_max=retps[-1],uniform_expectation=expected,p_magnetic=p_mag,p_proximity_min=p_prox_low,p_proximity_max=p_prox_high)
        arr.append(v)
    if name=='Cu':
        ci=ei
        for f,lab in enumerate(['F1','F2','F3','F4']):
            rho,p=spearmanr(xlf,frac[:,f,ei]);cor.append(dict(target=lab,rho=float(rho),p=float(p)))
        for tid,lab in [(0,'four-fraction sum'),(1,'F1'),(2,'non-residual')]:
            rho,p=spearmanr(xlf,Y[:,tid,ei]);cor.append(dict(target=lab,rho=float(rho),p=float(p)))

def regress(y):
    z=np.log(y);q=np.log1p(d);u=np.log(xlf)
    out={}
    for typ,X in [('distance-only',np.column_stack((np.ones(n),q))),('distance-plus-XLF',np.column_stack((np.ones(n),q,u)))]:
        beta=np.linalg.lstsq(X,z,rcond=None)[0]; pred=X@beta;err=z-pred;nparams=X.shape[1];sigma=np.sum(err**2)/(n-nparams)
        stderr=np.sqrt(np.diag(np.linalg.inv(X.T@X))*sigma)
        r2=1-np.sum(err**2)/np.sum((z-z.mean())**2)
        H=np.sum(X*(X@np.linalg.inv(X.T@X)),axis=1);loores=err/(1-H)
        pvals=2*student_t.sf(np.abs(beta/stderr),df=n-nparams)
        out[typ]={'beta':beta.tolist(),'se':stderr.tolist(),'p':pvals.tolist(),'R2':float(r2),'loocv_rmse':float(np.sqrt(np.mean(loores**2))),'df':n-nparams}
    return out
ols={lab:regress(Y[:,i,3]) for i,lab in enumerate(['four-fraction sum','F1','non-residual'])}

# Two record-order halves are only sensitivity strata; do not infer campaigns, batches or sampling phases.
half=[]
for lo,hi in [(0,16),(16,32)]:
    population=np.arange(lo,hi)
    for k in [4,8]:
        m=cutoff_sets(population,xlf,k,True);p=cutoff_sets(population,d,k)
        for ti,label in enumerate(['four-fraction sum','F1','non-residual']):
            y=Y[:,ti,3];rv=retention(m[0],y,population);rs=[retention(s,y,population) for s in p]
            cls='M' if rv > max(rs)+1e-10 else ('P' if rv < min(rs)-1e-10 else 'O')
            half.append(dict(records=f'{lo+1}-{hi}',k=k,target=label,magnetic=rv,proximity_min=min(rs),proximity_max=max(rs),classification=cls,proximity_set_count=len(p)))

order_half=[]
for ei,name in enumerate(names):
    z=Y[:,0,ei]
    u,p=mannwhitneyu(z[:16],z[16:],alternative='two-sided',method='asymptotic')
    ro,po=spearmanr(ids,z)
    order_half.append(dict(element=name,min_1_16=float(z[:16].min()),max_1_16=float(z[:16].max()),min_17_32=float(z[16:].min()),max_17_32=float(z[16:].max()),MannWhitney_p=float(p),Spearman_record_order=float(ro)))

# Coordinates DMS parsed with north/east signs, no original georeferenced boundary assumed.
def dms(t):
    z=re.search(r'(\d+)°(\d+)[\'’](\d+(?:\.\d+)?)["”]?',t.strip());assert z,t
    return float(z[1])+float(z[2])/60+float(z[3])/3600
lat=np.array([dms(r[53]) for r in rows]);lon=np.array([dms(r[54]) for r in rows]);
def hav(i,j):
    phi1,phi2=np.radians(lat[i]),np.radians(lat[j]);dphi=phi2-phi1;dl=np.radians(lon[j]-lon[i]);a=np.sin(dphi/2)**2+np.cos(phi1)*np.cos(phi2)*np.sin(dl/2)**2
    return 6371008.8*2*np.arctan2(np.sqrt(a),np.sqrt(1-a))
zeros=np.where(d==0)[0];sep17={int(ids[i]):float(hav(16,i)) for i in zeros}
zero_dist=[float(hav(i,j)) for i,j in itertools.combinations(zeros,2)]
center=(32+23/60+14.68/3600,36+16/60+9.17/3600)
chi_fd_from_stored=100*(xlf-xhf)/xlf
chi_fd_from_raw=100*(lf-hf)/lf
cu_share_f4=frac[:,3,3]/Y[:,0,3]

# Separate results for primary manuscript and supplementary summary.
summary=dict(n=32,budget=8,magnetic_selected_records=sorted(map(int,ids[list(M[0])])),nearest_set_count=len(P),random_chance_exact=True,random_ref=arr,Cu_fraction_spearman=cor,LOOCV_OLS=ols,record_order_halves=half,half_diagnostic=order_half,record17_to_zeros_m=sep17,zero_group_min_separation_m=min(zero_dist),zero_group_max_separation_m=max(zero_dist),record17_coordinates=[float(lat[16]),float(lon[16])],thesis_approx_location=list(center),xlf_xhf_spearman=spearmanr(xlf,xhf).statistic,xlf_distance_spearman=spearmanr(xlf,d).statistic,raw_susceptibility_sample_mass=[float(mass.min()),float(mass.max())],XFD_stored_percent=[float(np.min(chi_fd_from_stored)),float(np.median(chi_fd_from_stored)),float(np.max(chi_fd_from_stored))],XFD_raw_percent=[float(np.min(chi_fd_from_raw)),float(np.median(chi_fd_from_raw)),float(np.max(chi_fd_from_raw))],XFD_8_stored=float(chi_fd_from_stored[7]),XFD_8_raw=float(chi_fd_from_raw[7]),F4_Cu_mean_share=float(cu_share_f4.mean()),F4_Cu_median_share=float(np.median(cu_share_f4)))
(ROOT/'v37_analysis_results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
for fn,record in [('chance_k8_exact.csv',arr),('Cu_spearman_fractions.csv',cor),('record_order_halves.csv',half),('order_half_element_diagnostic.csv',order_half)]:
    with open(ROOT/fn,'w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=record[0].keys());writer.writeheader();writer.writerows(record)
with open(ROOT/'Cu_OLS_coefficients.csv','w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['target','model','coefficient','beta','standard_error','p_value','R2','LOOCV_RMSE'])
    for target,models in ols.items():
        for model,values in models.items():
            for j,param in enumerate(['intercept','ln(1+d/d0)','ln(XLF/x0)'][:len(values['beta'])]):
                writer.writerow([target,model,param,values['beta'][j],values['se'][j],values['p'][j],values['R2'],values['loocv_rmse']])
with open(ROOT/'concentrations_by_element_fraction.csv','w',newline='') as f:
    w=csv.writer(f);w.writerow(['element','fraction','min','q1','median','q3','max','units'])
    for ei,name in enumerate(names):
        for fi,flab in enumerate(['F1','F2','F3','F4']):
            v=frac[:,fi,ei];w.writerow([name,flab,np.min(v),np.quantile(v,.25),np.median(v),np.quantile(v,.75),np.max(v),'ug/g'])
with open(ROOT/'coordinates_reconstructed.csv','w',newline='') as f:
    w=csv.writer(f);w.writerow(['record','latitude_decimal_degrees','longitude_decimal_degrees','recorded_distance_m','direction_arabic'])
    for i in range(32):w.writerow([int(ids[i]),lat[i],lon[i],d[i],direction[i]])
print('VERIFY k8 magnetic Cu values:',[(v['target'],round(v['magnetic'],4),round(v['proximity_min'],4),round(v['proximity_max'],4),round(v['uniform_expectation'],4),round(v['p_magnetic'],5)) for v in arr if v['element']=='Cu'])
print('CU SPEARMAN:',cor)
print('OLS',json.dumps(ols,indent=2))
print('HALVES',half)
print('17',sep17,'zero range',min(zero_dist),max(zero_dist))
print('XFD',summary['XFD_stored_percent'],summary['XFD_raw_percent'],'record 8',summary['XFD_8_stored'],summary['XFD_8_raw'])
