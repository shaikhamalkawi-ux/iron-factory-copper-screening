#!/usr/bin/env python3
"""Reproduce reviewer-requested results without modifying the frozen workbook.
Standard-library XLSX/XML read; NumPy and SciPy required for the preserved analyses.
Run from any directory: python run_reproduction.py --output /path/to/new_results
"""
from pathlib import Path
import argparse, csv, hashlib, itertools, json, math, os, shutil, subprocess, sys, tempfile, zipfile
import xml.etree.ElementTree as ET
from collections import Counter

ROOT=Path(__file__).resolve().parent
SHA='1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b'
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def read_rows(path):
    """Read stored constants; refuse formula cells rather than recalculate them."""
    with zipfile.ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            shared=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
        ws=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        rows=[[None]*60 for _ in range(35)]
        for c in ws.findall('.//s:sheetData/s:row/s:c',NS):
            addr=c.get('r'); col=''.join(x for x in addr if x.isalpha()); r=int(''.join(x for x in addr if x.isdigit()))
            ci=0
            for a in col: ci=ci*26+ord(a)-64
            if r>35 or ci>60: continue
            if c.find('s:f',NS) is not None: raise ValueError('Unexpected formula '+addr)
            v=c.find('s:v',NS); typ=c.get('t')
            if typ=='inlineStr': value=''.join(c.find('s:is',NS).itertext())
            elif v is None: value=None
            elif typ=='s': value=shared[int(v.text)]
            elif typ in ('str','e'): value=v.text
            else: value=float(v.text)
            rows[r-1][ci-1]=value
    assert [int(r[0]) for r in rows[3:]]==list(range(1,33))
    return rows

def compare_csv(actual, expected, tolerance=1e-8):
    with actual.open(newline='',encoding='utf-8-sig') as f:a=list(csv.DictReader(f))
    with expected.open(newline='',encoding='utf-8-sig') as f:b=list(csv.DictReader(f))
    assert len(a)==len(b),(actual.name,len(a),len(b))
    error=0.
    for i,(ra,rb) in enumerate(zip(a,b)):
        assert ra.keys()==rb.keys(),(actual.name,'columns')
        for k in ra:
            try:
                x,y=float(ra[k]),float(rb[k]);err=abs(x-y);error=max(error,err)
                assert err<=tolerance*max(1.,abs(y)),(actual.name,i,k,x,y)
            except ValueError: assert ra[k]==rb[k],(actual.name,i,k,ra[k],rb[k])
    return {'rows':len(a),'maximum_absolute_difference':error}

def exhaustive_tie_check(rows):
    """Independent explicit boundary-subset enumeration vs scalar min/max bounds."""
    import numpy as np
    rec=rows[3:]; f=np.array([[[r[1+10*j+e] for e in range(9)] for j in range(4)] for r in rec],float)
    y=np.stack((f.sum(axis=1),f[:,0,:],f[:,:3,:].sum(axis=1)),axis=1)
    x=np.array([r[58] for r in rec]);d=np.array([r[52] for r in rec]);records=[]; maxerr=0.
    def sets(v,k,reverse):
        cutoff=sorted(v,reverse=reverse)[k-1]
        core=[i for i,z in enumerate(v) if (z>cutoff if reverse else z<cutoff)]
        ties=[i for i,z in enumerate(v) if z==cutoff];left=k-len(core)
        return [tuple(sorted(core+list(p))) for p in itertools.combinations(ties,left)],core,ties,left
    for k in range(1,32):
        ms,mc,mt,mn=sets(x,k,True);ps,pc,pt,pn=sets(d,k,False)
        for e,el in enumerate(['Cd','Co','Cr','Cu','Fe','Mn','Ni','Pb','Zn']):
            for t,tn in enumerate(['four-fraction sum','F1','non-residual']):
                z=y[:,t,e]; den=sum(sorted(z,reverse=True)[:k]);m=[sum(z[list(s)])/den for s in ms];p=[sum(z[list(s)])/den for s in ps]
                lohi=[min(m),max(m),min(p),max(p)]
                scal=[]
                for core,tie,left in [(mc,mt,mn),(pc,pt,pn)]:
                    v=sorted(z[tie]);c=sum(z[core]);scal.extend([(c+sum(v[:left]))/den,(c+sum(v[-left:]))/den])
                maxerr=max(maxerr,max(abs(a-b) for a,b in zip(lohi,scal)))
                assert np.allclose(lohi,scal,rtol=0,atol=1e-12)
                win='M' if lohi[0]>lohi[3]+1e-12 else ('P' if lohi[2]>lohi[1]+1e-12 else 'O')
                records.append({'element':el,'target':tn,'k':k,'XLF_min':lohi[0]*100,'XLF_max':lohi[1]*100,'distance_min':lohi[2]*100,'distance_max':lohi[3]*100,'winner':win,'XLF_tie_sets':len(ms),'distance_tie_sets':len(ps)})
    return records,maxerr

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'results');args=ap.parse_args()
    dest=args.output.resolve();dest.mkdir(parents=True,exist_ok=True)
    source=ROOT/'source/Iron_Factory_public_sanitized.xlsx';before=hashlib.sha256(source.read_bytes()).hexdigest();assert before==SHA,'Source hash mismatch'
    rows=read_rows(source)
    with tempfile.TemporaryDirectory(prefix='iron_revision_') as tmp:
        work=Path(tmp);shutil.copy2(source,work/source.name)
        (work/'public_0.json').write_text(json.dumps(rows,ensure_ascii=False))
        logs=[]
        for filename in ['reproduce_v37.py','verify_primary_and_halves.py']:
            shutil.copy2(ROOT/'code'/filename,work/filename)
            p=subprocess.run([sys.executable,str(work/filename)],cwd=work,capture_output=True,text=True,check=True)
            logs.append('### '+filename+'\n'+p.stdout+p.stderr)
        checks={}
        for expected in (ROOT/'expected_v38').glob('*.csv'):
            actual=work/expected.name
            if not actual.exists(): actual=work/'output'/expected.name
            if not actual.exists(): continue
            checks[expected.name]=compare_csv(actual,expected)
            shutil.copy2(actual,dest/actual.name)
        shutil.copy2(work/'v37_analysis_results.json',dest/'reviewer_analysis_results.json')
        shutil.copy2(work/'output/Iron_V38_HalfSplit_60_Comparisons.csv',dest/'row_order_half_comparisons.csv')
        shutil.copy2(work/'output/Iron_V38_Fraction_Medians_32Rows.csv',dest/'fraction_medians.csv')
        verified=json.loads((work/'output/Iron_V38_Independent_Numerical_QA.json').read_text())
        (dest/'reproduction.log').write_text('\n'.join(logs))
    primary,error=exhaustive_tie_check(rows)
    with (dest/'all_837_primary_cases.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=primary[0]);wr.writeheader();wr.writerows(primary)
    import numpy as np, scipy, platform
    rec=rows[3:];x=np.array([r[58] for r in rec]);h=np.array([r[59] for r in rec]);l=np.array([r[55] for r in rec]);hh=np.array([r[56] for r in rec])
    stored=100*(x-h)/x;raw=100*(l-hh)/l
    with (dest/'frequency_dependence_diagnostics.csv').open('w',newline='') as f:
        wr=csv.writer(f);wr.writerow(['record','XFD_stored_percent','relative_raw_LF_HF_percent','record8_XHF_provenance_flag'])
        wr.writerows((i+1,float(stored[i]),float(raw[i]),i==7) for i in range(32))
    fd={}
    for label,a in [('stored_all32',stored),('stored_excluding_record8',np.delete(stored,7)),('raw_all32',raw),('raw_excluding_record8',np.delete(raw,7))]:
        fd[label]={'n':len(a),'min':float(a.min()),'median':float(np.median(a)),'max':float(a.max())}
    (dest/'frequency_dependence_summary.json').write_text(json.dumps(fd,indent=2))
    splits=[math.comb(16,a)*math.comb(16,8-a) for a in range(9)];assert sum(splits)==math.comb(32,8)==10518300
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    verified.update({'all_837_cases_independent_tie_enumeration':True,'max_scalar_vs_enumeration_ratio_error':error,'chance_split_counts_a_0_to_8':splits,'chance_population_subsets':sum(splits),'reproduced_tables':checks,'source_sha256_after':before,'source_unchanged':True,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform()},'XFD_source_diagnostics':fd})
    (dest/'V39_Numerical_QA.json').write_text(json.dumps(verified,indent=2))
    print(json.dumps(verified,indent=2))
if __name__=='__main__':main()
