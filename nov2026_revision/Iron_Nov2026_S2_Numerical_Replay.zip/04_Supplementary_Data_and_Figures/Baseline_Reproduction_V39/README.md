# Reviewer analyses and reproducibility

This archive accompanies environments-4640261, revision Iron V39. It does not contain the private original workbook, the thesis, reviewer identities, or unpublished related manuscripts.

## Run

Use Python 3.13 (tested: 3.13.5). Install the recorded dependencies, then run from any working directory:

```text
python -m pip install -r requirements.txt
python run_reproduction.py --output reproduced
```

The script reads stored XLSX constants with the standard library; it never saves or changes the source workbook. Its expected SHA-256 is checked before and after execution. `code/reproduce_v37.py` retains the earlier numerical implementation. `code/verify_primary_and_halves.py` retains the V38 calculations with portable paths. `expected_v38/` supplies immutable comparison fixtures, not newly generated evidence.

## What the current run checks

All 837 ordinary element/target/budget cases are checked using independent explicit cutoff-subset enumeration versus scalar bounds. The 81 baseline printed k=8 retention values match to their recorded two-decimal display precision. Sixty record-order comparisons, 27 exact finite-uniform chance outcomes, Cu fraction correlations, both OLS specifications, concentration summaries and coordinates reproduce the nine archived CSVs with maximum numerical difference 0.0. All 10,518,300 size-eight subsets are counted through all a+(8-a) splits for a=0,...,8, not just the balanced split.

`results/V39_Numerical_QA.json` records the actual environment and scope. `frequency_dependence_diagnostics.csv` adds the transparent stored-pair/raw-reading comparison and record-8 omission diagnostic; it does not correct source XHF or establish calibrated XFD screening.

## Scope of inherited results

The historical single/pair-deletion analyses, full secondary minimum-of-four optimization/enumeration, original crosswalk, and older magnetic-ranking profiles are documented in the baseline repository rather than claimed as newly rerun here. The revision’s manuscript distinguishes that baseline from this accompanying archive. Repository: https://github.com/shaikhamalkawi-ux/iron-factory-copper-screening . The repository records DOI 10.5281/zenodo.23019081, but publication of this V39 archive at that DOI has not been verified or performed.

All findings describe the supplied historical records. Calibration, sample independence, dedicated sequential-extraction CRM recovery, thesis sharing/reuse and related-manuscript overlap are not validated by numerical reproduction.

`qa/Source_Readback_Parity.json` documents an additional artifact_tool versus XLSX/XML readback comparison performed during preparation; artifact_tool is not a dependency of the supplied reproduction script.

The source derivative SHA-256 is 1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b. The private original is preserved separately and excluded here.
