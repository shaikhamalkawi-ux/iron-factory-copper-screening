# Iron / Environments — Complete Four-Figure Source and Rebuild Audit

**Scope:** Publication-asset reproducibility of Figure 1, Figure 2, Figure 3, and Supplementary Figure S1. This is a **figure-only internal audit** based entirely on the frozen public-safe Iron source and the historical V57/V61 figure scripts. It does **not** change manuscript results, tables, data, plot content, labels, scientific conclusions, or the journal submission ZIP.

## Reproduce from a clean ZIP extraction

```bash
bash run_all.sh
```

The script uses bundled input data and executes, in order:
1. `scripts/build_v61_visuals.py` — main Figure 2 and supplementary Figure S1, including 837 numeric cross-checks against source workbook and frozen result matrix.
2. `scripts/build_v61_fig3.py` — Figure 3 from frozen Cu-retention and exact uniform-subset reference CSVs.
3. `source/render_figures_V57.py` — Figure 1 map from 32 archived coordinate values and the explicitly bundled low-resolution Jordan outline. It also draws an obsolete Figure 3 layout into `map_stage` only. **That Figure 3 is NOT used**; Figure 3 from the V61 layout is the published appearance target.
4. `scripts/verify_4_figures.py` — each output PDF compared with the exact original publication asset in `published_reference/`, requiring **identical MediaBox and identical RGB pixel values at 216 dpi**. PDF bytes need not match because generated metadata and source timestamps differ.
5. `scripts/render_600dpi.py` — renders uniform 600 dpi PNG print previews for all four published PDFs, following the reliable vector-PDF + 600 dpi PNG packaging convention seen in the independent Karak EP6R8 manuscript.

## Inputs and provenance

- `source/coordinates_reconstructed.csv` — 32 historical records, with zero-distance codes unchanged.
- `source/Jordan_NaturalEarth_LowResolution.geojson` — archived general Jordan outline; **not a new survey**.
- `inputs/Iron_Factory_public_sanitized.xlsx` — public-safe frozen source worksheet, not the confidential original.
- `inputs/all_837_primary_cases.csv` — 837 fixed screening outputs.
- `inputs/chance_k8_exact.csv` — fixed exact k=8 expected references.
- `inputs/Cu_Uniform_Expectation_By_Budget.csv` — fixed uniform-reference curves.
- `published_reference/` — four exact PDF artwork files embedded in the November 2026 Iron source; source binaries frozen for parity audit.
- `scripts/` contains frozen V57/V61 figure-code copies and verification scripts; no external websites, credentials or API tokens are required.

## How to interpret 'exact'

With the tested Python environment, all four reconstructed figures have identical PDF page dimensions and **zero pixel mismatches in full-page 216 dpi rasterization** against the source PDFs. The numerical cross-check maximum difference is approximately `9.95e-14` percentage points. Source vs generated PDFs have different SHA-256 hashes because PDF creation timestamps (and possibly document IDs) differ: **do not report byte-for-byte PDF identity**.

## Distinction from Karak

Karak EP6R8's Overleaf source ZIP contains six visually clear print PDF charts and 600 dpi PNG counterparts, all linked by the manuscript and supplement. The **source ZIP itself does not contain plot-generation scripts or input measurements**, so it is a print-production example rather than a complete statistical rerun package. This Iron closure supplements the print PDFs with executable reconstruction and pixel parity verification.

## Limits

- This audit establishes **figure replay from admitted data**, not independent field measurement or calibration verification.
- Plot-source files remain fixed and should not be interpreted as journal permission to share the confidential original workbook or any unpublished thesis preview token.
- Do not upload `published_reference` or this full internal bundle to the journal unless the editor specifically requests the figure-source package. The four figure PDFs already exist in the journal LaTeX source and Supplementary Materials.

## Portable November 2026 maintenance

The public figure renderer now reads the **hash-locked sanitized workbook numeric cells** directly from its OOXML using Python standard libraries. No separately installed spreadsheet reader is necessary. It checks row count, sample IDs, the exact set of required numeric cells, and SHA-256 before generating plots. The rendering script is still the same numerical and graphical algorithm; input values, reference PDFs and all figure decisions remain unchanged.
