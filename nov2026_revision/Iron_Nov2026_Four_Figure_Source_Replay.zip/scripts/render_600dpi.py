#!/usr/bin/env python3
from pathlib import Path
import fitz
R=Path(__file__).resolve().parent.parent
out=R/'print_ready_600dpi'
out.mkdir(exist_ok=True)
for path in sorted((R/'published_reference').glob('Figure*.pdf')):
 d=fitz.open(path);assert d.page_count==1
 p=d[0].get_pixmap(dpi=600,colorspace=fitz.csRGB,alpha=False)
 p.save(out/(path.stem+'_600dpi.png'))
 print(path.stem,p.width,'x',p.height)
