#!/usr/bin/env python3
"""Independent geometry and 216-dpi pixel parity validator for four Iron figures."""
from pathlib import Path
import json,hashlib
import fitz
R=Path(__file__).resolve().parent.parent
assets=['Figure1_Study_Area_and_Records.pdf','Figure2_Target_Aware_Classification.pdf',
 'Figure3_Cu_Retention_Envelopes.pdf','FigureS1_Minimum_Four_Retention.pdf']
q={'comparison_render_dpi':216,'threshold':'exact pixel bytes (no tolerance)','figures':{},'all_pass':True}
for name in assets:
 expected,got=R/'published_reference'/name,R/'output'/name
 assert expected.exists() and got.exists(),name
 a,b=fitz.open(expected),fitz.open(got)
 rect_same=a.page_count==b.page_count==1 and a[0].rect==b[0].rect
 ma=a[0].get_pixmap(dpi=216,colorspace=fitz.csRGB,alpha=False)
 mb=b[0].get_pixmap(dpi=216,colorspace=fitz.csRGB,alpha=False)
 pixels_same=(ma.width==mb.width and ma.height==mb.height and ma.samples==mb.samples)
 forbidden_types=[f for f in b[0].get_fonts() if f[2]=='Type3']
 passed=rect_same and pixels_same and not forbidden_types
 q['all_pass'] &= passed
 q['figures'][name]={
   'pdf_byte_identical':hashlib.sha256(expected.read_bytes()).digest()==hashlib.sha256(got.read_bytes()).digest(),
   'page_dimensions_equal':rect_same,'pixel_identical_216dpi':pixels_same,
   'no_Type3_fonts':not forbidden_types,'pass':passed,
   'bbox_pt':list(a[0].rect),'pixels_at_216dpi':[ma.width,ma.height],
   'reference_sha256':hashlib.sha256(expected.read_bytes()).hexdigest(),
   'rebuilt_sha256':hashlib.sha256(got.read_bytes()).hexdigest(),
   'reference_creationDate':a.metadata.get('creationDate'),
   'rebuilt_creationDate':b.metadata.get('creationDate')}
 a.close();b.close()
 assert passed,name
(R/'output'/'REBUILD_FIGURE_PARITY_QA.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({'all_pass':q['all_pass'],'figure_count':len(assets),'all_pixel_identical_216dpi':all(v['pixel_identical_216dpi'] for v in q['figures'].values()),'all_page_dimensions_equal':all(v['page_dimensions_equal'] for v in q['figures'].values())},indent=2))
