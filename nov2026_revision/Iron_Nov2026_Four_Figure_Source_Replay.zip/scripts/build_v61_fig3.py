"""Regenerate manuscript Figure 3 from frozen numerical CSVs; typography only."""
import csv, pathlib, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
base=pathlib.Path(__file__).resolve().parent.parent
out=base/'output'
rr=list(csv.DictReader((base/'inputs/all_837_primary_cases.csv').open()))
ex=list(csv.DictReader((base/'inputs/Cu_Uniform_Expectation_By_Budget.csv').open()))
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.8})
targs=['four-fraction sum','F1','non-residual']
titles=['(a) Four-fraction Cu sum','(b) Acid-soluble F1 Cu','(c) Non-residual Cu']
fig,axs=plt.subplots(1,3,figsize=(9.6,3.6),sharey=True)
for i,(t,title) in enumerate(zip(targs,titles)):
 ax=axs[i]
 z=sorted((r for r in rr if r['element']=='Cu' and r['target']==t),key=lambda x:int(x['k']))
 assert len(z)==31
 k=np.array([int(r['k']) for r in z]);values={x:np.array([float(r[x]) for r in z]) for x in ['XLF_min','XLF_max','distance_min','distance_max']}
 l,u,d,du=[values[x] for x in ['XLF_min','XLF_max','distance_min','distance_max']]
 ec=[float(r['uniform_expectation_percent']) for r in ex if r['target']==t]
 assert len(ec)==31
 # Colors and data unchanged relative to the frozen V60 chart.
 ax.fill_between(k,d,du,color='#1f77b4',alpha=.16,linewidth=0)
 ax.plot(k,d,color='#1f77b4',linestyle='--',linewidth=1.4)
 ax.plot(k,du,color='#1f77b4',linestyle='--',linewidth=1.4)
 ax.plot(k,ec,color='#2ca02c',linestyle='-.',linewidth=1.65)
 ax.errorbar(k,l,yerr=np.vstack([np.zeros(len(k)),u-l]),fmt='-',color='#ff7f0e',linewidth=1.75,
             elinewidth=1.35,capsize=2.3,capthick=1.05)
 ax.axvline(8,color='#1f77b4',linestyle=':',linewidth=1.05,alpha=.87)
 ax.set_xlim(.45,31.8);ax.set_ylim(0,102.5)
 ax.set_xticks([1,8,15,23,31]);ax.set_yticks([0,20,40,60,80,100]);ax.tick_params(labelsize=11.0,pad=2.5)
 ax.set_title(title,fontsize=12.8,pad=9)
 ax.grid(alpha=.16,linewidth=.8)
 ax.set_xlabel('Selection budget k',fontsize=11.4,labelpad=5)
 if i==0:ax.set_ylabel('Retention (%)',fontsize=11.7,labelpad=5)
fig.subplots_adjust(left=.07,right=.99,top=.86,bottom=.36,wspace=.15)
legend=[Line2D([],[],color='#ff7f0e',linewidth=1.85,marker='|',markersize=8,label='XLF lower + tie range'),
        Line2D([],[],color='#1f77b4',linewidth=1.5,linestyle='--',label='Proximity envelope'),
        Line2D([],[],color='#2ca02c',linewidth=1.7,linestyle='-.',label='Uniform-subset mean'),
        Line2D([],[],color='#1f77b4',linewidth=1.1,linestyle=':',label='k = 8')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.06),ncol=4,fontsize=10.4,
           frameon=False,handlelength=2.3,columnspacing=1.7)
fig.savefig(out/'Figure3_Cu_Retention_Envelopes.pdf',facecolor='white')
fig.savefig(out/'Figure3_Cu_Retention_Envelopes.png',dpi=450,facecolor='white')
plt.close(fig)
print('regenerated from',len(rr),'frozen rows')
