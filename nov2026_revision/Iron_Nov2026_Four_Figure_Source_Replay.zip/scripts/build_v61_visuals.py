"""Iron V61 FIGURE-ONLY typography regeneration; fixed scientific inputs.

Input: 32-row sanctioned/sanitized workbook and frozen 837-case table. No user
weights, thresholds, experiments or data corrections are introduced.
"""
from pathlib import Path
import math, csv, json, itertools, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, TwoSlopeNorm, BoundaryNorm
from matplotlib.patches import Rectangle
from artifact_tool import Blob,SpreadsheetFile
import fitz

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'inputs'
OUT=ROOT/'output'
OUT.mkdir(parents=True,exist_ok=True)
EL=['Cd','Co','Cr','Cu','Fe','Mn','Ni','Pb','Zn']
TARGET=['four-fraction sum','F1','non-residual']
FIXED=list(csv.DictReader((DATA/'all_837_primary_cases.csv').open()))
LU={(d['element'],d['target'],int(d['k'])):d for d in FIXED}
assert len(LU)==837

plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42,
                     'axes.linewidth':.75,'xtick.major.width':.6,'ytick.major.width':.6,
                     'savefig.facecolor':'white'})

# First image uses only exactly admitted classifications and chance expectations.
C=np.empty((3,9,31),dtype=np.int8)
for j,t in enumerate(TARGET):
 for i,e in enumerate(EL):
  for k in range(1,32):
   C[j,i,k-1]={'O':0,'M':1,'P':2}[LU[e,t,k]['winner']]
chance=list(csv.DictReader((DATA/'chance_k8_exact.csv').open()))
assert len(chance)==27
h={(d['element'],d['target']):float(d['magnetic'])-float(d['uniform_expectation']) for d in chance}
D=np.array([[h[(e,t)] for t in TARGET] for e in EL])
for i,e in enumerate(EL):
 for j,t in enumerate(TARGET):
  assert math.isclose(D[i,j],float(LU[e,t,8]['XLF_min'])-next(float(r['uniform_expectation']) for r in chance if r['element']==e and r['target']==t),abs_tol=1e-11)
assert [LU['Cu',t,8]['winner'] for t in TARGET]==['M','M','P']

fig=plt.figure(figsize=(8.4,10.2),layout=None)
gs=fig.add_gridspec(2,2,left=.085,right=.95,bottom=.115,top=.955,wspace=.25,hspace=.27)
cmap=ListedColormap(['#E8E8E8','#437EAB','#CC725F'])
axes=[]
for j,t in enumerate(TARGET):
 ax=fig.add_subplot(gs[j//2,j%2]);axes.append(ax)
 ax.pcolormesh(np.arange(.5,32.5,1),np.arange(-.5,9.5,1),C[j],shading='flat',
               cmap=cmap,norm=BoundaryNorm([-.5,.5,1.5,2.5],3),rasterized=False,antialiased=False)
 ax.axvline(8,color='black',linestyle='--',linewidth=1.0,alpha=.8)
 ax.add_patch(Rectangle((.5,3-.5),31,1,fill=False,edgecolor='black',linewidth=1.65))
 ax.set(xlim=(.5,31.5),ylim=(8.5,-.5))
 ax.set_xticks([1,8,15,23,31],labels=['1','8','15','23','31'],fontsize=11)
 ax.set_yticks(range(9),labels=EL,fontsize=11)
 ax.tick_params(length=3,pad=4)
 ax.set_xlabel('Selection budget k',fontsize=12,labelpad=3)
 ax.set_title(['(a) Four-fraction sum','(b) F1','(c) F1+F2+F3'][j],fontsize=13.5,pad=10)
ax=fig.add_subplot(gs[1,1]);axes.append(ax)
mesh=ax.imshow(D,interpolation='none',cmap='RdBu',norm=TwoSlopeNorm(vcenter=0,vmin=-50,vmax=50),aspect='auto')
ax.set_xticks(range(3),['Sum','F1','NR'],fontsize=11)
ax.set_yticks(range(9),EL,fontsize=11)
ax.set_title('(d) XLF minus uniform mean',fontsize=13.5,pad=10)
ax.set_xlabel('Percentage points at k = 8',fontsize=12,labelpad=3)
for i in range(9):
 for j in range(3):
  v=D[i,j]; ax.text(j,i,f'{v:+.0f}',ha='center',va='center',color='white' if abs(v)>32 else 'black',fontsize=11)
# Compact discrete meaning key, same colors as source figure.
from matplotlib.patches import Patch
legend=[Patch(facecolor='#437EAB',label='XLF strictly better'),
        Patch(facecolor='#CC725F',label='Proximity strictly better'),
        Patch(facecolor='#E8E8E8',edgecolor='#8f8f8f',label='Overlap')]
fig.legend(handles=legend,ncol=3,loc='lower center',bbox_to_anchor=(.5,.032),frameon=False,fontsize=11,handlelength=1.2,columnspacing=1.7)
fig.savefig(OUT/'Figure2_Target_Aware_Classification.pdf',facecolor='white')
fig.savefig(OUT/'Figure1_target_aware_screening_layout2x2.png',dpi=600,facecolor='white')
plt.close(fig)

# Reconstruct S1 minimum-of-four curves from public workbook. Validate ranking
# against all 837 archived target cases before admitting the new graphic.
w=SpreadsheetFile.import_xlsx(Blob.load(str(DATA/'Iron_Factory_public_sanitized.xlsx')))
rows=w.worksheets.get_item('All rsults').get_range('A4:BH35').values
assert len(rows)==32 and all(int(r[0])==i+1 for i,r in enumerate(rows))
chem=np.zeros((9,4,32),float)
for f,start in enumerate([1,11,21,31]):
 for e in range(9):
  chem[e,f,:]=[float(row[start+e]) for row in rows]
xlf=np.asarray([float(row[58]) for row in rows]);dist=np.asarray([float(row[52]) for row in rows])
assert np.all(np.isfinite(chem)) and np.all(chem>0)

# Enumerate all admissible tie cutoff subsets (range exact; no arbitrary row tie-break).
def tied_selections(scores,k,descending=True):
 v=np.asarray(scores,float)
 order=np.argsort(-v if descending else v,kind='stable')
 vals=v[order]; cut=vals[k-1]
 strict=[int(ind) for ind in order if (v[ind]>cut if descending else v[ind]<cut)]
 tied=[int(ind) for ind in order if v[ind]==cut]
 q=k-len(strict)
 return [tuple(sorted(strict+list(c))) for c in itertools.combinations(tied,q)]

mincurves={}
maxdif=0.0
mismatch=[]
for ei,e in enumerate(EL):
 for k in range(1,32):
  mag=tied_selections(xlf,k,True);prox=tied_selections(dist,k,False)
  assert len(mag)==int(LU[e,'F1',k]['XLF_tie_sets'])
  assert len(prox)==int(LU[e,'F1',k]['distance_tie_sets'])
  oracle=np.sort(chem[ei],axis=1)[:,-k:].sum(axis=1)
  def retain(S):return (100*np.asarray([chem[ei,f,list(S)].sum() for f in range(4)])/oracle).min()
  magr=[retain(s) for s in mag];proxr=[retain(s) for s in prox]
  mincurves[e,k]={'mag_min':min(magr),'mag_max':max(magr),'prox_min':min(proxr),'prox_max':max(proxr)}
  for tgt,frac_index in [('four-fraction sum',None),('F1',0),('non-residual',None)]:
   if tgt=='four-fraction sum':z=chem[ei].sum(axis=0)
   elif tgt=='F1':z=chem[ei,0]
   else:z=chem[ei,:3].sum(axis=0)
   denom=np.sort(z)[-k:].sum()
   checkM=[100*z[list(s)].sum()/denom for s in mag]
   checkP=[100*z[list(s)].sum()/denom for s in prox]
   ref=LU[e,tgt,k]
   vals=(min(checkM),max(checkM),min(checkP),max(checkP))
   orig=tuple(float(ref[y]) for y in ('XLF_min','XLF_max','distance_min','distance_max'))
   error=max(abs(a-b) for a,b in zip(vals,orig));maxdif=max(maxdif,error)
   if error>1e-8:mismatch.append((e,tgt,k,error))
assert not mismatch,(maxdif,mismatch[:4])
assert maxdif<1e-9

# Nine-panel vector supplementary plot. Published axes, colors and data are preserved.
fig,axs=plt.subplots(3,3,figsize=(9.1,7.1),sharex=True,sharey=True)
for i,e in enumerate(EL):
 ax=axs.flat[i]
 x=np.arange(1,32)
 Ma=np.array([mincurves[e,k]['mag_min'] for k in x]);Mb=np.array([mincurves[e,k]['mag_max'] for k in x])
 Pa=np.array([mincurves[e,k]['prox_min'] for k in x]);Pb=np.array([mincurves[e,k]['prox_max'] for k in x])
 if (Mb-Ma).max()>1e-9:ax.fill_between(x,Ma,Mb,alpha=.17,color='#14869e',linewidth=0)
 if (Pb-Pa).max()>1e-9:ax.fill_between(x,Pa,Pb,alpha=.17,color='#cb731e',linewidth=0)
 ax.plot(x,Ma,color='#1387a4',linewidth=1.65,label='Highest XLF')
 ax.plot(x,Pa,color='#c46a1e',linewidth=1.65,label='Nearest recorded distance')
 ax.axvline(8,linestyle=':',color='#8b8b8b',linewidth=1.0)
 ax.set_xlim(.5,31.5);ax.set_ylim(0,101.8)
 ax.set_xticks([1,8,15,23,31]);ax.set_yticks([0,25,50,75,100])
 ax.set_title(e,fontsize=13.2,pad=7)
 ax.grid(alpha=.15)
 ax.tick_params(axis='both',labelsize=10.8,length=2.7,pad=2)
 if i//3==2:ax.set_xlabel('Selected records (k)',fontsize=11.5,labelpad=3)
 if i%3==0:ax.set_ylabel('Minimum retention (%)',fontsize=11.3,labelpad=4)
fig.suptitle('Rule comparison changes with the budget',fontsize=15,y=.97)
handles,labels=axs.flat[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.928),ncol=2,frameon=False,fontsize=11.7,handlelength=2.5)
fig.subplots_adjust(left=.088,right=.985,bottom=.096,top=.85,wspace=.20,hspace=.24)
fig.savefig(OUT/'FigureS1_Minimum_Four_Retention.pdf',facecolor='white')
fig.savefig(OUT/'proximity_budget_profiles.png',dpi=600,facecolor='white')
plt.close(fig)

# Numeric lock and plot-source transparency report.
summary={'n_records':len(rows),'n_primary_cases':len(FIXED),'n_recomputed_crosschecks':9*31*3,
 'max_abs_retention_percentage_point_difference':maxdif,'k8_winners_Cu':[LU['Cu',t,8]['winner'] for t in TARGET],
 'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.iterdir() if p.is_file()},
 'k8_minimum_four':{e:mincurves[e,8] for e in EL}}
(OUT/'figure_rebuild_numeric_validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('input_sha256','k8_minimum_four')},indent=2))
