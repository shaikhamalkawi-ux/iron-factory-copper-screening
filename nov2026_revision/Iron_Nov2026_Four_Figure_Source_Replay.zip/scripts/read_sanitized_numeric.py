"""Read the locked numeric cells from the public sanitized XLSX using stdlib.

This is an exact, purpose-limited OOXML numeric reader, not a general-purpose
Excel parser. The source file is SHA-256 locked; only cached numeric cell
values in the `All rsults` sheet, rows 4--35, are needed for the plots.

No formulas are recalculated, no workbook or measurement is modified.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import re
import xml.etree.ElementTree as ET

EXPECTED_SHA256 = '1f403f49d399643455cffaad47d4445dee8acfba40ca14b6452283bd9e7e6b8b'
SS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PKG = '{http://schemas.openxmlformats.org/package/2006/relationships}'
CELL_REF = re.compile(r'^([A-Z]+)([1-9][0-9]*)$')
# A=0 = archived sample ID; four 9-element blocks, BA=52=distance, BG=58=XLF.
REQUIRED = {0, 52, 58} | {start+i for start in (1,11,21,31) for i in range(9)}


def col_index(label):
    n = 0
    for c in label:
        n = n * 26 + (ord(c) - ord('A') + 1)
    return n - 1


def load_32_numeric_rows(path):
    path = Path(path)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != EXPECTED_SHA256:
        raise ValueError('Workbook hash mismatch: refusing a different source file')

    with ZipFile(path) as book:
        if book.testzip() is not None:
            raise ValueError('Workbook ZIP integrity failure')
        root = ET.fromstring(book.read('xl/workbook.xml'))
        sheets = [s for s in root.findall(f'.//{SS}sheets/{SS}sheet') if s.get('name') == 'All rsults']
        if len(sheets) != 1:
            raise ValueError('Expected one sheet named All rsults')
        sheet_id = sheets[0].get(f'{REL}id')
        rel_root = ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))
        targets = [r.get('Target') for r in rel_root.findall(f'{PKG}Relationship') if r.get('Id') == sheet_id]
        if len(targets) != 1:
            raise ValueError('Cannot locate the locked workbook sheet')
        target = targets[0].lstrip('/')
        if not target.startswith('xl/'):
            target = 'xl/' + target
        data = ET.fromstring(book.read(target))
        records = {}
        for row in data.findall(f'.//{SS}sheetData/{SS}row'):
            rnum = int(row.get('r'))
            if rnum not in range(4, 36):
                continue
            numeric = [None] * 60
            found = set()
            for cell in row.findall(f'{SS}c'):
                ref = cell.get('r', '')
                match = CELL_REF.match(ref)
                if not match or int(match.group(2)) != rnum:
                    continue
                idx = col_index(match.group(1))
                if idx not in REQUIRED:
                    continue
                if cell.get('t') in ('s', 'str', 'inlineStr', 'e'):
                    raise ValueError(f'Unexpected text/error in required numeric cell {ref}')
                value = cell.find(f'{SS}v')
                if value is None or value.text is None:
                    raise ValueError(f'Missing numeric cached value in {ref}')
                numeric[idx] = float(value.text)
                found.add(idx)
            if found != REQUIRED:
                missing = sorted(REQUIRED-found)
                raise ValueError(f'Missing required numeric columns in worksheet row {rnum}: {missing}')
            records[rnum] = numeric
        if sorted(records) != list(range(4, 36)):
            raise ValueError('Expected exactly 32 original source rows')
        rows = [records[i] for i in range(4, 36)]
        if any(int(row[0]) != j for j, row in enumerate(rows, 1)):
            raise ValueError('Sample IDs 1--32 are not in the locked original order')
        return rows
