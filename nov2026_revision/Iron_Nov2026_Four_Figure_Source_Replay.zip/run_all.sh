#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
mkdir -p output map_stage
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/build_v61_visuals.py
python3 scripts/build_v61_fig3.py
python3 source/render_figures_V57.py --output map_stage
cp map_stage/Figure1_Study_Area_and_Records.pdf output/
cp map_stage/Figure1_Study_Area_and_Records.png output/
python3 scripts/verify_4_figures.py
python3 scripts/render_600dpi.py
printf '\nPASS: all four figures recreated from source inputs and are pixel-identical to the fixed publication assets at 216 dpi.\n'
